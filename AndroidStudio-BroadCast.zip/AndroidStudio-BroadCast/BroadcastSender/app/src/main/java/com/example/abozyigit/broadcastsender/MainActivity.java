package com.example.abozyigit.broadcastsender;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Context context = this;
    DB db =new DB(context) ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void startOnClick(View view) {
        //uygulamadan bağımsız sürekli gönderim yapabilmek için servis kullanıyoruz
        Intent intent= new Intent(this,MySenderService.class);
        startService(intent);
    }

    public void stopOnClick(View view) {
        Intent intent= new Intent(this,MySenderService.class);
        stopService(intent);
    }
}
