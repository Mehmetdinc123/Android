package com.example.abozyigit.broadcastsender;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {

    private static final int database_VERSION=1;
    private static final String database_Name="SurelerDB";
    private static final String table_Sure="Sureler";
    private static final String Sure_ID="id";
    private static final String Sure_Gun="gun";
    private static final String Sure_Saniye="sure";
    private static final String CREATE_SURE_TABLE="CREATE TABLE "
            +table_Sure+" ("
            +Sure_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
            +Sure_Gun+" TEXT, "
            +Sure_Saniye+" TEXT )";




    public DB(@androidx.annotation.Nullable Context context) {
        super(context, database_Name, null, database_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_SURE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(" DROP TABLE IF EXISTS "+table_Sure);
        this.onCreate(db);
    }

    public void sureEkle(MySenderService sure){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues degerler=new ContentValues();
        degerler.put(Sure_Gun,sure.getSure());
        degerler.put(Sure_Saniye,sure.getSure());
        db.insert(table_Sure,null,degerler);
        db.close();
    }
}
