package com.example.abozyigit.broadcastsender;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import java.util.Random;

public class MySenderService extends Service {

    int id;
    int gun;
    int sure;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGun() {
        return gun;
    }

    public void setGun(int gun) {
        this.gun = gun;
    }

    public int getSure() {
        return sure;
    }

    public void setSure(int sure) {
        this.sure = sure;
    }

    static Handler handler=new Handler();
    public MySenderService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
    int val=1;
    //saniyede bir değer gönderiyor.
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {



                Intent intent=new Intent();
                intent.setAction("TIMER");
                intent.putExtra("value",val);
                sendBroadcast(intent);
                val++;
                handler.postDelayed(this,1000);

            }
        };
        handler.postDelayed(runnable,1000);

        return START_STICKY;
    }
}
