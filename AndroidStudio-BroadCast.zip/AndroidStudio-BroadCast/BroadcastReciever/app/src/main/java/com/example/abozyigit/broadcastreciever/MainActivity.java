package com.example.abozyigit.broadcastreciever;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    static TextView tv_result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_result= findViewById(R.id.tv_result);
    }



    public void startOnClick(View view) {
        //uygulamadan bağımsız broadcast'ı sürekli dinlemek için servis başlattık.
        Intent service = new Intent(this, MyRecieverService.class);
        startService(service);


    }

    public void stopOnClick(View view) {
        Intent service = new Intent(this, MyRecieverService.class);
        stopService(service);
    }

}
