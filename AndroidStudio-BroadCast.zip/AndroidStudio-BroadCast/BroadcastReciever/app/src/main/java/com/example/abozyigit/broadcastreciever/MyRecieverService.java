package com.example.abozyigit.broadcastreciever;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;

public class MyRecieverService extends Service {
    //servis aktif olduğu sürece dinleme yapcak listener
    private static BroadcastReceiver myReciver;

    public MyRecieverService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
    @Override
    public void onCreate()
    {
        registerMyReciver();
    }

    @Override
    public void onDestroy()
    {
        unregisterReceiver(myReciver);
        myReciver = null;
    }

    private void registerMyReciver()
    {
        myReciver = new BroadcastReceiver()
        {
            //uygulama  yok olsa bile log atıyor, logcat'de görebilirsiniz

            @Override
            public void onReceive(Context context, Intent intent)
            {
                //sistem aksiyonları, ödevinizle alaklı olan
                if (intent.getAction()==Intent.ACTION_SCREEN_OFF)
                {
                    Log.d("test", "ACTION_SCREEN_OFF");

                }
                //sistem aksiyonları, ödevinizle alaklı olan
                else if (intent.getAction()==Intent.ACTION_SCREEN_ON)
                {
                    Log.d("test", "ACTION_SCREEN_ON");
                }
                //bu aksiyon bizim broadcastsender uygulamasından gelcek
                else if (intent.getAction()=="TIMER")
                {
                    int val=intent.getIntExtra("value",0);
                    //uygulama kapandığında hata alıp broadcast durmasın diye, çünkü mainactivity uçmuş olcak
                    try
                    {
                        MainActivity.tv_result.setText(val+"");
                    }
                    catch (Exception ex)
                    {
                        Log.v("test","main aktivite nesnesi yok olduğundan süre tutulamadı!");
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction("TIMER");


        registerReceiver(myReciver, filter);
    }
}
